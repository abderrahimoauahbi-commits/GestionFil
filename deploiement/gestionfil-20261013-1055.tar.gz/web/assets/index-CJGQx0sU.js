import{i}from"./core-uYr82bVc.js";async function a(n=0){await i("plugin:process|exit",{code:n})}async function e(){await i("plugin:process|restart")}export{a as exit,e as relaunch};
